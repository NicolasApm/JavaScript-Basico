persona = {
  nombre: "luis",
  apellido: "torres",
  telefonos: ["123123","321321"],
  direccion: {
      estado: "principal",
      ciudad: "dorado",
      calle: "7",
      casa: 5
  }
}

