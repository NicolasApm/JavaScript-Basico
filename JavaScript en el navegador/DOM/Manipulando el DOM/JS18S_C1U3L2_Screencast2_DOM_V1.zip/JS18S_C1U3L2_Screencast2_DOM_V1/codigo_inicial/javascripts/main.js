function saludar(){
  alert("Bienvenido JS");
}

