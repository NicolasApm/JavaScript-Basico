function enviarMensaje(mensaje){
  alert(mensaje);
  console.log(mensaje);
}

function inicio(){
  enviarMensaje("Hola");
  enviarMensaje("Adios");
}

inicio();
