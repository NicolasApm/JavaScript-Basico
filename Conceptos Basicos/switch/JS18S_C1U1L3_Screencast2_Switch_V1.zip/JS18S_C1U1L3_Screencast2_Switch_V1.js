var color = "azul";

switch(color){
  case "rojo":
    console.log("FF0000");
    break;
  case "negro":
    console.log("000000");
    break;
  case "azul":
    console.log("0000FF");
    break;
  default:
    console.log("???");
}
