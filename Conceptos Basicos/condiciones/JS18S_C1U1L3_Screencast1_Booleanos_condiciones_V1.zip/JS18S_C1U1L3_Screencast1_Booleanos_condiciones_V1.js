var tieneCocina = false;
var tieneWifi = true;
var maximaOcupacion = 4;
var lugar = "Ciudad";

if (lugar == "Playa"){
  console.log("Hotel A1");
}
else if (lugar == "Lago"){
  console.log("Hotel B2");
}
else{
  console.log("Hotel C3");
}
