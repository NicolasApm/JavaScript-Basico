var edad = 15;
console.log(edad);

var distancia = 1.5;
console.log(distancia);

var nombre = "luis";
console.log(nombre);

var colores = ["rojo", "blanco", "azul"];
console.log(colores[2]);

var persona = { "altura": 160, colorDeOjos: "café"};
console.log(persona.colorDeOjos);

var estaActivo = false;
console.log(estaActivo);

var a = 1;
var b = 3;

var c = a + b;
console.log(c);

var nombreYEdad = "Nombre: " + nombre + ", Edad: " + edad;
console.log(nombreYEdad);
