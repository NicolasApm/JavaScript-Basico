
function saludar(nombre, apellido, curso){

  var resultado = `Hola ${nombre} ${apellido}, bienvenido al curso ${curso}`
  return resultado;

}

console.log(saludar("Maria", "Gil", "C++"));
