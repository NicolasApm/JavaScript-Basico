var arreglo = [3,4,5,6,7,8];

var suma = 0;

for (var elemento of arreglo){
    suma = suma + elemento;
}

console.log(suma);