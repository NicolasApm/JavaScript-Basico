// Hemos omitido los acentos en los comentarios por compatibilidad

function validar(formulario) {

  //Expresion regular del correo

}
